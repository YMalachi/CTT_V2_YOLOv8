# CTT_V2_YOLOv8 > 2025-04-13 6:54pm
https://universe.roboflow.com/yotams-workspace/ctt_v2_yolov8

Provided by a Roboflow user
License: CC BY 4.0

